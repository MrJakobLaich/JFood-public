
recipes =
{
    ["burger-bun"] =
    {
        result = "burger-bun",
        time = 1,
        output = 1,
        ingredients =
        {
            {"wheat", 16}
        }
    },
    ["sushi"] =
    {
        result = "sushi",
        time = 1,
        output = 5,
        ingredients =
        {
            {"raw-fish", 10}
        }
    },
    ["water-bottle"] =
    {
        result = "water-bottle",
        time = 1,
        output = 1,
        ingredients =
        {
            {"wood", 1}
        }
    }
    -- ["wheat"] =
    -- {
    --     result = "wheat",
    --     time = 1,
    --     output = 4,
    --     ingredients =
    --     {
    --         {"wood", 1}
    --     }
    -- }
}